ac=@(x)sin(x)./exp(1);
s=integral(ac,pi/4,pi/2);