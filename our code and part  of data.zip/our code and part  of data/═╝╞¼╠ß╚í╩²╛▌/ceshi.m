data=xlsread('selfdefine.xls','sheet1','A:A');
plot(data)