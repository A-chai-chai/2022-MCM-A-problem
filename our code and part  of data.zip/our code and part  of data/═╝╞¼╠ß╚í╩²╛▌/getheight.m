clc;
clear;
%读入原图像
image = imread('define.jpg');
s = size(image);
p_r = image(30,30,1);
p_g = image(30,30,2);
p_b = image(30,30,3);
%分别读取RGB
image_r = image(:,:,1);
image_g = image(:,:,2);
image_b = image(:,:,3);
%测试RGB输出
subplot(2,2,1),imshow(image_r),title('Red component');  
subplot(2,2,2),imshow(image_g),title('green component');  
subplot(2,2,3),imshow(image_g),title('blue component');  
subplot(2,2,4),imshow(image),title('original image');
len=457;
width=1466;
A=zeros(width,1);
for i=1:len
    for j=1:width
        image_r(i,j)=image_r(len+1-i,j);
    end
end
for i=1:len
    for j=1:width
        if (image_r(i,j)>240)&&(A(j,1)==0)
            A(j,1)=(i-1)*150/len;
        end
    end
end
figure
plot(A)
xlswrite('selfdefine.xls',A,1);