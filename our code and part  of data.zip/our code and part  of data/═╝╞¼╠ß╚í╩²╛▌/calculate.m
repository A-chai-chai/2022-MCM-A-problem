A=load('red.txt');
B=load('green.txt');
C=load('blue.txt');
for i=1:572
    for j=1:572
        D(i,j)=10*A(i,j)+6*B(i,j)+1*C(i,j);
    end
end
fprintf("D=%d ",D);