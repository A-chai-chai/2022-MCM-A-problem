data=xlsread('女子单人.xls','sheet1','A:A');
plot(data)