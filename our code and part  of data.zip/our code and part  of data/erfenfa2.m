clc;
clear;
%模拟退火算法
%data=xlsread('men elite.xls');
T0=100;
Tf=1;
%t0=0;
Tsum=0;
Tmap=420;
Tli(1)=0;
%降温公式T(t)=T0/log(t+1)
%概率采用Metropolis法则
BMR=1.2;
MAP=27.15;
E=-5.89;
A=1314.67;
k1=30;
k2=20;
f=-0.233;
M=60;
m=10;
Li=886;
g=9.8;
R=0.00466;
lamda=0.19;
omega=0;
cos=1;
sin=0;
t0=1;

accuracy=0.0001;
%精确度为0.0001
x=Tli(t0)+150;
%每次二分区间定为Tli(t0)到x，长度为150
F=100;
a=Tli(t0);
b=x;
%二分区间
direction=0;
while abs(F)>accuracy
    if direction==0
        b=x;
    else
        a=x;
    end
    x=(a+b)./2;
    fx=@(t)(BMR+(MAP-BMR+E.*log(Tsum+1)).*(1-exp(-t/k1)));
    integralval=integral(fx,Tli(t0),x);
    S=A.*(1+f.*log(Tsum+1));
    power=6.6.*(integralval+S.*(1-exp(-x./k2)))./(x-Tli(t0));
    Gravity=((M+m).*g.*sin-(M+m).*g.*R).*Li./(x-Tli(t0));
    resistance=lamda.*((Li./(x-Tli(t0))-omega.*cos).^2).*Li./(x-Tli(t0));
    F=power-Gravity-resistance;  
    %二分
    if F>0
        direction=0;
        %下一个二分区间取左端
    else
        direction=1;
        %下一个二分区间取右端
    end
end
Tli(t0+1)=x;

