learn=zeros(49,1);
%存放加速路段的序号值
randval=randperm(49);
randvalnew=randval(1,1:5);
%49个随机整数排序取前5个
for i=1:5
    learn(randvalnew(1,i))=1;
end