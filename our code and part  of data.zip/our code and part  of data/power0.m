clc
clear
%模拟退火算法
data=xlsread('男子团体.xls');
%TURN=xlsread('turn.xls');
frequency=0;
T0=100;
T=T0;
Tf=100;
t00=1;
Tsum=0;
Tmap=420;
Tli(1,1)=0;
Tmin=10000000;
Tnew=0;
%概率采用Metropolis法则
BMR=1.2;
% MAP=26.041;
% E=-5.44;
% A=1061;
MAP=28.038;
E=-5.7768;
A=1653.0625;
% MAP=25.74;
% E=-5.945;
% A=1566.57;
% MAP=28.038;
% E=-5.7768;
% A=1653.062;
% MAP=25.74;%SPE
% E=-5.95;
% A=1566.57;
k1=30;
k2=20;
f=-0.233;
M=60;
m=10;
Li=441.18;
g=9.8;
R=0.00466;
lamda=0.19;
omega=0;
%fi=xlsread('flanders_women_wind.xls');
sin0=0;
accelerate=9;
%加速段数
section=51;
%路段数
%定义一些常数值
learn=zeros(section,1);
%存放加速路段的序号值
randval=randperm(section);
randvalnew=randval(1,1:accelerate);
%section个随机整数排序取前accelerate个
for i=1:accelerate
    learn(randvalnew(1,i))=1;
end
%把learn中加速路段赋值1
while T>=Tf
   frequency=frequency+1;
   t00=t00+1;
   %T=T0/log(t00+1);
   T=T0/t00;
   %降温公式
   speed=[11 15 16 17 22 29 33 37 38]';
   %每次循环开始加入一个随机偏移量（2）
        t0=1;
        Tli(1,1)=0;
        x=0;
        Tsum=0;
        for P=1:section
            cos0=cos(fi(P));
            %每个小段相当于step米 
            if P<section
                h=data((P+1).*12)-data(P.*12);
            else
                h=0;
            end
            sin0(P)=sin(h./Li);       
            %if TURN()   
            if Tli(t0,1)<Tmap
                %二分法求Tli(t0+1)的值
                accuracy=0.0001;
                %精确度为0.0001
                x=Tli(t0,1)+200;
                %每次二分区间定为Tli(t0)到x，长度为150
                F=100;
                a=Tli(t0,1);
                b=x;
                %二分区间
                direction=0;
                num3=0;
                while abs(F)>accuracy
                    if direction==0
                        b=x;
                    else
                        a=x;
                    end
                    x=(a+b)./2;
                    fx=@(t)(BMR+(MAP-BMR).*(1-exp(-t/k1)));
                    integralval=integral(fx,Tli(t0,1),x);
                    S=A;
                    power(P)=0.165.*60.*(integralval+S.*(1-exp(-x./k2)))./(x-Tli(t0,1));
                    %如果是加速段，功率power*1.1
                    for i=1:accelerate
                        if speed(i,1)==P
                            power(P)=power(P).*1.1;
                            num3=num3+1;
                        end
                    end
                    Gravity=((M+m).*g.*sin0(P)-(M+m).*g.*R).*Li./(x-Tli(t0,1));
                    resistance=lamda.*((Li./(x-Tli(t0,1))-omega.*cos0).^2).*Li./(x-Tli(t0,1));
                    F=power(P)-Gravity-resistance;  
                    %二分
                    if F>0
                        direction=0;
                        %下一个二分区间取左端
                    else
                        direction=1;
                        %下一个二分区间取右端
                    end
                end
                if num3>=1
                    Tsum=Tsum+x-Tli(t0);
                end
                Tli(t0+1,1)=x;
                Tpower(P)=x-Tli(t0,1);
            elseif Tli(t0,1)>=Tmap 
                %二分法求Tli(t0+1)的值
                accuracy=0.0001;
                %精确度为0.0001
                x=Tli(t0,1)+200;
                %每次二分区间定为Tli(t0)到x，长度为150
                F=100;
                a=Tli(t0,1);
                b=x;
                %二分区间
                direction=0;
                num2=0;
                while abs(F)>accuracy
                    if direction==0
                        b=x;
                    else
                        a=x;
                    end
                    x=(a+b)./2;
                    fx=@(t)(BMR+(MAP-BMR+1.6.*log(Tsum./Tmap+1)+E.*log(x./Tmap)).*(1-exp(-t/k1)));
                    integralval=integral(fx,Tli(t0,1),x);
                    S=A.*(1+f.*log(x./Tmap)+0.012.*log(Tsum./Tmap+1));
                    power(P)=0.165.*60.*(integralval+S.*(1-exp(-x./k2)))./(x-Tli(t0,1));
                    %如果是加速段，功率power*1.1
                    for i=1:accelerate
                        if speed(i,1)==P
                            power(P)=power(P).*1.1;
                            num2=num2+1;
                        end
                    end
                    Gravity=((M+m).*g.*sin0(P)-(M+m).*g.*R).*Li./(x-Tli(t0,1));
                    resistance=lamda.*((Li./(x-Tli(t0,1))-omega.*cos0).^2).*Li./(x-Tli(t0,1));
                    F=power(P)-Gravity-resistance;  
                    %二分
                    if F>0
                        direction=0;
                        %下一个二分区间取左端
                    else
                        direction=1;
                        %下一个二分区间取右端
                    end
                end
                if num2>=1
                    Tsum=Tsum+x-Tli(t0);
                end
                Tli(t0+1)=x;  
                Tpower(P)=x-Tli(t0,1);
            end
            Tnew=x;
            t0=t0+1;
        end
        %概率采用Metropolis法则
        dE=abs(Tnew-Tmin);
        if Tnew<Tmin
            %此次解优于上次解时接受此次状态
            Tmin=Tnew;
            solution=speed;        
        else
            %此次解劣于上次解时有概率接受此次状态，有概率退回上次状态
            if exp(-dE./T) >= rand
               solution=speed; 
            end
        end
end
xlswrite('Tpower(1).xls',Tpower,1);
for i=1:section
    if i==1
        Tpower(i)=Tpower(i);
    else
        Tpower(i)=Tpower(i)+Tpower(i-1);
    end
end
xlswrite('power(1).xls',power,1);

plot(Tpower,power)
values = spcrv([[Tpower(1) Tpower Tpower(end)];[power(1) power power(end)]],4);
xlswrite('values(1).xls',values,1);
plot(values(1,:),values(2,:), 'b');