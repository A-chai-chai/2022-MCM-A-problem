clc
clear
%模拟退火算法
data=xlsread('men elite.xls');
%TURN=xlsread('turn.xls');
frequency=0;
T0=100;
T=T0;
Tf=100;
t00=1;
Tsum=0;
Tmap=420;
Tli(1,1)=0;
Tmin=10000000;
Tnew=0;
%概率采用Metropolis法则
BMR=1.2;
MAP=28.038;
E=-5.7768;
A=1653.0625;
k1=30;
k2=20;
f=-0.1;
M=60;
m=10;
Li=904.08;
%每段路的长度
g=9.8;
R=0.00466;
lamda=0.19;
omega=0;
%fi=xlsread('flanders_women_wind.xls');
sin0(1)=0;
accelerate=9;
%加速段数
section=49;
%路段数
%定义一些常数值
learn=zeros(section,1);
%存放加速路段的序号值
randval=randperm(section);
randvalnew=randval(1,1:accelerate);
%section个随机整数排序取前accelerate个
for i=1:accelerate
    learn(randvalnew(1,i))=1;
end
%把learn中加速路段赋值1
while T>=Tf
   frequency=frequency+1;
   t00=t00+1;
   %T=T0/log(t00+1);
   T=T0/t00;
   %降温公式
   %每次循环开始时为learn赋予新的随机偏移量
   speed=[41;42;43;39;45;46;47;48;49];
   %每次循环开始加入一个随机偏移量（2）
        t0=1;
        Tli(1,1)=0;
        x=0;
        Tsum=0;
        for P=1:section
            %cos0=cos(fi(P));
            cos0=0;
            %每个小段相当于step米 
            if P<section
                h=data((P+1).*10)-data(P.*10);
            else
                h=0;
            end
            sin0(P)=sin(h./Li);       
            %if TURN()   
            if Tli(t0,1)<Tmap
                %二分法求Tli(t0+1)的值
                accuracy=0.0001;
                %精确度为0.0001
                x=Tli(t0,1)+1000;
                %每次二分区间定为Tli(t0)到x，长度为150
                F=100;
                a=Tli(t0,1);
                b=x;
                %二分区间
                direction=0;
                num3=0;
                while abs(F)>accuracy
                    if direction==0
                        b=x;
                    else
                        a=x;
                    end
                    x=(a+b)./2;
                    fx=@(t)(BMR+(MAP-BMR).*(1-exp(-t/k1)));
                    integralval=integral(fx,Tli(t0,1),x);
                    S=A;
                    power(P)=0.12.*60.*(integralval+S.*(1-exp(-x./k2)))./(x-Tli(t0,1));
                    %如果是加速段，功率power*1.1
                    for i=1:accelerate
                        if speed(i,1)==P
                            power(P)=power(P).*1.1;
                            num3=num3+1;
                        end
                    end
                    Gravity=((M+m).*g.*sin0(P)-(M+m).*g.*R).*Li./(x-Tli(t0,1));
                    resistance=lamda.*((Li./(x-Tli(t0,1))-omega.*cos0).^2).*Li./(x-Tli(t0,1));
                    F=power(P)-Gravity-resistance;  
                    %二分
                    if F>0
                        direction=0;
                        %下一个二分区间取左端
                    else
                        direction=1;
                        %下一个二分区间取右端
                    end
                end
                if num3>=1
                    Tsum=Tsum+x-Tli(t0);
                end
                Tli(t0+1,1)=x;
                Tpower(P)=x-Tli(t0,1);
            elseif Tli(t0,1)>=Tmap 
                %二分法求Tli(t0+1)的值
                accuracy=0.0001;
                %精确度为0.0001
                x=Tli(t0,1)+1000;
                %每次二分区间定为Tli(t0)到x，长度为150
                F=100;
                a=Tli(t0,1);
                b=x;
                %二分区间
                direction=0;
                num2=0;
                while abs(F)>accuracy
                    if direction==0
                        b=x;
                    else
                        a=x;
                    end
                    x=(a+b)./2;
                    fx=@(t)(BMR+(MAP-BMR+E.*log(Tsum./Tmap+1)+E.*log(x./Tmap)).*(1-exp(-t/k1)));
                    integralval=integral(fx,Tli(t0,1),x);
                    S=A.*(1+f.*log(x./Tmap)+f.*log(Tsum./Tmap+1));
                    power(P)=0.12.*60.*(integralval+S.*(1-exp(-x./k2)))./(x-Tli(t0,1));
                    %如果是加速段，功率power*1.1
                    for i=1:accelerate
                        if speed(i,1)==P
                            power(P)=power(P).*1.1;
                            num2=num2+1;
                        end
                    end
                    Gravity=((M+m).*g.*sin0(P)-(M+m).*g.*R).*Li./(x-Tli(t0,1));
                    resistance=lamda.*((Li./(x-Tli(t0,1))-omega.*cos0).^2).*Li./(x-Tli(t0,1));
                    F=power(P)-Gravity-resistance;  
                    %二分
                    if F>0
                        direction=0;
                        %下一个二分区间取左端
                    else
                        direction=1;
                        %下一个二分区间取右端
                    end
                end
                if num2>=1
                    Tsum=Tsum+x-Tli(t0);
                end
                Tli(t0+1)=x;    
                Tpower(P)=x-Tli(t0,1);
            end
            Tnew=x;
            t0=t0+1;
        end
        %概率采用Metropolis法则
        dE=abs(Tnew-Tmin);
        if Tnew<Tmin
            %此次解优于上次解时接受此次状态
            Tmin=Tnew;
            solution=speed;        
        else
            %此次解劣于上次解时有概率接受此次状态，有概率退回上次状态
            if exp(-dE./T) >= rand
               solution=speed; 
            end
        end
end

for i=1:section
    if i==1
        Tpower(i)=Tpower(i);
    else
        Tpower(i)=Tpower(i)+Tpower(i-1);
    end
end
xlswrite('power(上坡和靠后加速的决策1).xls',power,1);
xlswrite('Tpower(上坡和靠后加速的决策1).xls',Tpower,1);
plot(Tpower,power)
values = spcrv([[Tpower(1) Tpower Tpower(end)];[power(1) power power(end)]],4);
xlswrite('values(上坡和靠后加速的决策1).xls',values,1);
plot(values(1,:),values(2,:), 'b');
xlswrite('坡度.xls',sin0,1);