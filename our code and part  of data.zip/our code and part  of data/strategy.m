clc
clear
%模拟退火算法
data=xlsread('men elite.xls');
%TURN=xlsread('turn.xls');
frequency=0;
T0=100;
T=T0;
Tf=100;
t00=1;
Tsum=0;
Tmap=420;
Tli(1,1)=0;
Tmin=10000000;
Tnew=0;
%概率采用Metropolis法则
BMR=1.2;
MAP=28.038;
E=-5.7768;
A=1653.0625;
k1=30;
k2=20;
f=-0.1;
M=60;
m=10;
Li=904.08;
%每段路的长度
g=9.8;
R=0.00466;
lamda=0.19;
omega=0;
%fi=xlsread('flanders_women_wind.xls');
sin0=0;
accelerate=10;
%加速段数
section=49;
%路段数
%定义一些常数值
learn=zeros(section,1);
%存放加速路段的序号值
randval=randperm(section);
randvalnew=randval(1,1:accelerate);
%section个随机整数排序取前accelerate个
for i=1:accelerate
    learn(randvalnew(1,i))=1;
end
%把learn中加速路段赋值1
while T>=Tf
   frequency=frequency+1;
   t00=t00+1;
   %T=T0/log(t00+1);
   T=T0/t00;
   %降温公式
   %每次循环开始时为learn赋予新的随机偏移量
   temlearn=learn;
   j=0;
   for i=1:section
       if temlearn(i,1)==1
           j=j+1;
           speed(j,1)=i;
           %speed临时存储加速区间           
       end
   end
   randIndex_speed = randperm(accelerate);
   speednew = speed(randIndex_speed);
   r=rand;
   if r>=0.5
       num=1;
       %向右
   else
       num=0;
       %向左
   end
   randval123=randperm(3);
   if speednew(1,1)<=randval123(1,1)&&num==0
       num=1;
   end
   if speednew(1,1)>=50-randval123(1,1)&&num==1
       num=0;
   end
   %如果越界则转向
   if num==1
       speed(1,1)=speed(1,1)+randval123(1,1);
   else
       speed(1,1)=speed(1,1)-randval123(1,1);
   end
  
   %如果偏移之后有重复的值，则随机取一个不加速的点作为新的加速区间
   speed2=zeros(section,1);
   for i=1:section
       for k=1:5
           if i==speed(k,1)
               speed2(i,1)=1;
           end
       end
   end
   jjj=0;
   for ii=1:accelerate
       for jj=1:accelerate
           if speed(ii,1)==speed(jj,1)&&(ii==jj)==0
              for iii=1:section
                  if speed2(iii,1)==0
                      jjj=jjj+1;
                      abandon(jjj,1)=speed2(iii,1);
                  end
              end
              randIndex_abandon = randperm(section-4);
              abandonnew = abandon(randIndex_abandon);
              speed(ii,1)=abandonnew(1,1);
           end
       end
   end
   %每次循环开始加入一个随机偏移量（2）
        t0=1;
        Tli(1,1)=0;
        x=0;
        Tsum=0;
        for P=1:section
            %cos0=cos(fi(P));
            cos0=0;
            %每个小段相当于step米 
            if P<section
                h=data((P+1).*10)-data(P.*10);
            else
                h=0;
            end
            sin0=sin(h./Li);       
            %if TURN()   
            if Tli(t0,1)<Tmap
                %二分法求Tli(t0+1)的值
                accuracy=0.0001;
                %精确度为0.0001
                x=Tli(t0,1)+1000;
                %每次二分区间定为Tli(t0)到x，长度为150
                F=100;
                a=Tli(t0,1);
                b=x;
                %二分区间
                direction=0;
                num3=0;
                while abs(F)>accuracy
                    if direction==0
                        b=x;
                    else
                        a=x;
                    end
                    x=(a+b)./2;
                    fx=@(t)(BMR+(MAP-BMR).*(1-exp(-t/k1)));
                    integralval=integral(fx,Tli(t0,1),x);
                    S=A;
                    power=0.11.*60.*(integralval+S.*(1-exp(-x./k2)))./(x-Tli(t0,1));
                    %如果是加速段，功率power*1.1
                    for i=1:accelerate
                        if speed(i,1)==P
                            power=power.*1.1;
                            num3=num3+1;
                        end
                    end
                    Gravity=((M+m).*g.*sin0-(M+m).*g.*R).*Li./(x-Tli(t0,1));
                    resistance=lamda.*((Li./(x-Tli(t0,1))-omega.*cos0).^2).*Li./(x-Tli(t0,1));
                    F=power-Gravity-resistance;  
                    %二分
                    if F>0
                        direction=0;
                        %下一个二分区间取左端
                    else
                        direction=1;
                        %下一个二分区间取右端
                    end
                end
                if num3>=1
                    Tsum=Tsum+x-Tli(t0);
                end
                Tli(t0+1,1)=x;
            elseif Tli(t0,1)>=Tmap 
                %二分法求Tli(t0+1)的值
                accuracy=0.0001;
                %精确度为0.0001
                x=Tli(t0,1)+1000;
                %每次二分区间定为Tli(t0)到x，长度为150
                F=100;
                a=Tli(t0,1);
                b=x;
                %二分区间
                direction=0;
                num2=0;
                while abs(F)>accuracy
                    if direction==0
                        b=x;
                    else
                        a=x;
                    end
                    x=(a+b)./2;
                    fx=@(t)(BMR+(MAP-BMR+E.*log(Tsum./Tmap+1)+E.*log(x./Tmap)).*(1-exp(-t/k1)));
                    integralval=integral(fx,Tli(t0,1),x);
                    S=A.*(1+f.*log(x./Tmap)+f.*log(Tsum./Tmap+1));
                    power=0.11.*60.*(integralval+S.*(1-exp(-x./k2)))./(x-Tli(t0,1));
                    %如果是加速段，功率power*1.1
                    for i=1:accelerate
                        if speed(i,1)==P
                            power=power.*1.1;
                            num2=num2+1;
                        end
                    end
                    Gravity=((M+m).*g.*sin0-(M+m).*g.*R).*Li./(x-Tli(t0,1));
                    resistance=lamda.*((Li./(x-Tli(t0,1))-omega.*cos0).^2).*Li./(x-Tli(t0,1));
                    F=power-Gravity-resistance;  
                    %二分
                    if F>0
                        direction=0;
                        %下一个二分区间取左端
                    else
                        direction=1;
                        %下一个二分区间取右端
                    end
                end
                if num2>=1
                    Tsum=Tsum+x-Tli(t0);
                end
                Tli(t0+1)=x;     
            end
            Tnew=x;
            t0=t0+1;
        end
        %概率采用Metropolis法则
        dE=abs(Tnew-Tmin);
        if Tnew<Tmin
            %此次解优于上次解时接受此次状态
            Tmin=Tnew;
            solution=speed;        
        else
            %此次解劣于上次解时有概率接受此次状态，有概率退回上次状态
            if exp(-dE./T) >= rand
               solution=speed; 
            end
        end
end