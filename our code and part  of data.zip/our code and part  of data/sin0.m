clc
clear
data=xlsread('men elite.xls');
step=886;
for P=1:49
    %每个小段相当于step米 
    if P<49
        h=data((P+1).*10)-data(P.*10);
    else
        h=0;
    end
    sin00(P)=sin(atan(180.*h./(step.*3.14)));
end